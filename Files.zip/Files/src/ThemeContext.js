import { createContext, useContext, useState } from "react";
const ThemeContext = createContext();

export const ThemeProvider = ({ children }) => {
    const [theme, setTheme] = useState("light");
    const toogleTheme = () => {
        setTheme(prev=> prev==="light"?"black":"light")
    }

    return <ThemeContext.Provider value={toogleTheme, theme}>
    {children}
</ThemeContext.Provider>;

}

export const useTheme = () =>{return useContext(ThemeContext);} 
