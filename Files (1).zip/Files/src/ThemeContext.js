import { createContext, useContext, useState } from "react";
const ThemeContext = createContext();


export const ThemeProvider = ({ children }) => {
    const [theme, setTheme] = useState("light");
    const toogleTheme = () => {
        setTheme(prev=> prev==="light"?"black":"light")
    }
    const ctxValue ={
    theme,toogleTheme
}

    return <ThemeContext.Provider value={ctxValue}>
    {children}
</ThemeContext.Provider>;

}

export const useTheme = () =>{return useContext(ThemeContext);} 